#include <iostream>
using namespace std;





int main(){
typedef struct student {
	char name[10];
	double high;
	double weight;
	char sex;
	int score;
}stuA[5];
 stuA[5]{
{"Joe",171.5,66.1,"M",95};
{"Dolly",160.3,55.3,"F",83};
{"Wallison",175.5,70.6,"M",92};
{"Andy",168.5,80.6,"M",88};
{"Helen",155.5,45.2,"F",77};
};
for(i=0,i<5,i++){
    if(stuA[i].score>stuA[i+1].score){
         tmp=stuA[i];	 
         stuA[i]=stuA[i+1];
		 stuA[i+1]=tmp;		
};	
};
for(i=0,i<5,i++){
	cout<<stuA[i]<<endl;
}




return 0;}
              
















