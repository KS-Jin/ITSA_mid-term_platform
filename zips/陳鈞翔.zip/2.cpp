#include <iostream>
using namespace std;
int main()
{
	
	
	cout<<"Joe,171.5,66.1,'M',95"<<endl; 
	cout<<"Andy,168.5,80.6,'M',88"<<endl;
	cout<<"Dolly,160.3,55.3,'F',83"<<endl;
	cout<<"Helen,155.5,45.2,'F',77"<<endl;
	cout<<"Wallison,175.5,70.6,'M',92"<<endl;
	
	
	return 0;
}
