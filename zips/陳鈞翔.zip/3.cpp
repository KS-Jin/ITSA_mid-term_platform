#include <iostream>
using namespace std;
int main()
{
	
	
	cout<<"�o�D�ڤ��|"<<endl; 
	
	
	return 0;
}
