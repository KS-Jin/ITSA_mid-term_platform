#include <iostream>
using namespace std;

int main()
{
	int Name;
	double H,W,P;
	char BG; 
	
	H=171.5;
	W=66.1;
	P=95;
	
	cout<<"Joe,"<<H<<","<<W<<","<<"M"<<","<<P<<endl;
	
	int Name1;
	double H1,W1,P1;
	char BG1; 
	
	H1=175.5;
	W1=70.6;
	P1=92;
	
	cout<<"Wallison,"<<H1<<","<<W1<<","<<"M"<<","<<P1<<endl;	

	int Name2;
	double H2,W2,P2;
	char BG2; 
	
	H2=168.5;
	W2=80.6;
	P2=88;
	
	cout<<"Andy,"<<H2<<","<<W2<<","<<"M"<<","<<P2<<endl;

	int Name3;
	double H3,W3,P3;
	char BG3; 
	
	H3=160.3;
	W3=53.3;
	P3=82;
	
	cout<<"Dolly,"<<H3<<","<<W3<<","<<"F"<<","<<P3<<endl;	

	int Name4;
	double H4,W4,P4;
	char BG4; 
	
	H4=155.5;
	W4=45.2;
	P4=77;
	
	cout<<"Helen,"<<H4<<","<<W4<<","<<"F"<<","<<P4<<endl;	
	return 0;
}






