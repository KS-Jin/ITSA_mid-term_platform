#include <iostream>
#include <string.h>
using namespace std;

int main()
{	
	
	typedef struct{
	char name[10];
	double tall;
	double weight;
	char sex;
	int score;
	}Student;
	
	Student studentAry = {"Joe",171.5,66.4,'M',95,};
	
	return 0;
}
