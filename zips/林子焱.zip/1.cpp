#include<iostream>
#include<string.h>
using namespace std;

typedef struct{
	char name[10];
	double len ;
	double we ;
	char sex[1];
	double scr ;
	
}student;

student studentAry[5]={
							{"Joe",171.5,66.1,'M',95},
							{"Dolly",160.3,55.3,'F',83},
							{"Wallison",175.5,70.6,'M',92},
							{"Andy",168.5,80.6,'M',88},
							{"Helen",155.5,45.2,'F',77},
							
						  };


void scp(int l)
{
	for(int i=0 ;i < l;i++)
	{
	for(int j=0;j < l-1-i;j++)
		{
			if(studentAry[i].scr>studentAry[i+1].scr)
			{
				cout<<i+1<<":"<<studentAry[i].name<<","<<studentAry[i].len<<","<<studentAry[i].we<<","<<studentAry[i].sex<<","<<studentAry[i].scr<<endl;
			}
			else
			{
				student studentBry=studentAry[i];
				studentAry[i]=studentAry[i+1];
				studentAry[i+1]=studentBry;
			}
		}
	}
}

bool BtoS(int a ,int b)
{
	a>b;
}

bool StoB(int a, int b)
{
	a<b;
}
int main()
{
	scp(5);

}


