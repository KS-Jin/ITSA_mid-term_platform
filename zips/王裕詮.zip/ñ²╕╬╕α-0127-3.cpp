#include <iostream>
#include <string.h>
using namespace std;

class student
{
	public:
		char name[10];
		float h;
		float w;
		char s;
		float score;
};

void show(student* stu,char vy)
{
	if(vy=='B')
	{
		for(int i=0;i<5;i++)
		{
		cout<<stu[i].name<<","<<stu[i].h<<","<<stu[i].w<<","<<stu[i].s<<","<<stu[i].score<<endl;
    	}
    }
    else if(vy=='S')
    {
    	for(int i=4;i>=0;i--)
		{
		cout<<stu[i].name<<","<<stu[i].h<<","<<stu[i].w<<","<<stu[i].s<<","<<stu[i].score<<endl;
    	}
	}
	else
	{
		cout<<"error"<<endl;
	}
}

int main()
{   
    char vx='\0';
	cout<<"Please enter(B  or  S):  ";
	cin>>vx;
	student ary[5]={{"Wallison",175.5,70.6,'M',88},
	                {"Dolly",160.3,55.3,'F',83},
				    {"Helen",155.5,45.2,'F',77},
					{"Andy",168.5,80.6,'M',88},
					{"Joe",171.5,66.1,'M',95}};
	show(ary,vx);
	return 0;
}
