#include <iostream>
#include <string.h>
using namespace std;

class student
{
	public:
		char name[10];
		float h;
		float w;
		char s;
		float score;
};

void show(student* stu)
{
	for(int i=0;i<5;i++)
	{
	cout<<stu[i].name<<","<<stu[i].h<<","<<stu[i].w<<","<<stu[i].s<<","<<stu[i].score<<endl;
    }
}

int main()
{
	student ary[5]={{"Joe",171.5,66.1,'M',95},
				    {"Wallison",175.5,70.6,'M',88},
					{"Andy",168.5,80.6,'M',88},
					{"Dolly",160.3,55.3,'F',83},
					{"Helen",155.5,45.2,'F',77}};
	show(ary);
	return 0;
}
