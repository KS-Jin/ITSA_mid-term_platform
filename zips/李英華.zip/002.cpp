#include <iostream>
using namespace std;
typedef struct {
	char name[10];
	double height;
	double weight;
	char sex;
	double score;  
}Student;
int count(Student& stu)
{
	int j=0;
	for(int i=0;i<10;i++)
	{
	j++;
	if(stu.name[i]=='\0')break;
	}
	return j;
}
void sort(Student* stu)
{
	for(int i=0;i<4;i++)
	{
		for(int c=0;c<4-i;c++)
		{
			if(count(stu[c]) > count(stu[c+1]))
			{
			Student x=stu[c];
			stu[c]=stu[c+1];
			stu[c+1]=x;	
			}
			else if(count(stu[c]) == count(stu[c+1])&&stu[c].score<stu[c+1].score)
			{
			Student x=stu[c];
			stu[c]=stu[c+1];
			stu[c+1]=x;	
			}
		}
	}
}
void show(Student& stu)
{
	cout<<stu.name<<" "<<stu.height<<" "<<stu.weight<<" "<<stu.sex<<" "<<stu.score<<endl;
}
int main()
{
	Student studentAry[5]={
							{"Joe",171.5,66.1,'M',95},
							{"Dolly",160.3,55.3,'F',83},
							{"Wallison",175.5,70.6,'M',92},
							{"Andy",168.5,80.6,'M',88},
							{"Helen",155.5,45.2,'F',77},
						};
	sort(studentAry);
	for(int i=0;i<5;i++)
	{
		cout<<i+1<<": ";
		show(studentAry[i]);
	}
	return 0;
}
