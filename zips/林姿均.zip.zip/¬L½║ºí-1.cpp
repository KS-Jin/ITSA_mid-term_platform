#include<iostream>
#include<string.h>
using namespace std;
char name;
double h;
double w;
int s;
int t;

int stuAry[5]= {name,h,w,s,t};
class studentary(stuAry)
{
	int ary[5]={"Joe",171.5,66.1,'M',95};
	int bary[5]={"Dolly",160.3,55.3,'F',83};
	int cary[5]={"wallison",175.5,70.6,'M',92};
	int dary[5]={"Andy",168.5,80.6,'M',88};
	int eary[5]={"Helen",155.5,45.2,'F',77};
}
int main()
{  
    int void;
    cout<<"Student studentAry[5]={"endl;
	cout<<"{"<<ary<<"}"<<","<<endl;
	cout<<"{"<<bry<<"}"<<","<<endl;
	cout<<"{"<<cary<<"}"<<","<<endl;
	cout<<"{"<<dary<<"}"<<","<<endl;
	cout<<"{"<<eary<<"}"<<","<<endl;
	cout<<"};";
	return 0;
}
