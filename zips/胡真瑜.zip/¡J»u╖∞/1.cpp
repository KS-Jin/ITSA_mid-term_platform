#include<iostream>
#include<string.h>
using namespace std;
void sort();
int main()
{
    typedef struct Student{
   	
   	char* name;
   	double tall;
   	double weight;
   	char* sex;
   	double grade;
   }Student;
   
   Student studentAry[5]={
                           {"Joe",171.5,66.1,'M',95},
                           {"Dolly",160.3,55.3,'F',83},
                           {"Wallison",175.5,70.6,'M',92},
                           {"Andy",168.5,80.6,'M',88},
                           {"Hellen",155.5,45.2,'F',77},
						   
   };
   return 0;
   
}
void sort(Student(studentAry[]),int L)
   {
   	 for(int c=0;c<L-1;c++)
   	 {
   	 	for(int i=0;i<L-1-c;i++)
			{
			 if (studentAry[i].grade>studentAry[i+1])
			 {
			  int tmp=studentAry[i];
			  studentAry[i]=studentAry[i+1]	;
			  studentAry[i+1]=tmp;
			 }	
			}
		}
   }
