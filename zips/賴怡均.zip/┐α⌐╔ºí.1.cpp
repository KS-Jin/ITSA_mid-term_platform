#include <iostream>
#include <string.h>
using namespace std;

typedef struct {
	char name[10];
	double high;
	double wight;
	char bg ;
	double garde;
} student;

void showstudent(const student& stu)
{
	cout << stu.name<< ","<< stu.high<< ","<< stu.wight<< ","<<  stu.bg<< ","<< stu.garde<< endl;
}

void sortstudentAry(student* stuAry , int L)
{
	for(int c = 0; c <  L - 1 ; c ++)
	{
		for(int i = 0 ; i < L - 1 - c ; i ++)
		{
			if(stuAry[i].garde < stuAry[i+1].garde)
			{
				student tmp = stuAry[i];
				stuAry[i] = stuAry[i+1];
				stuAry[i+1] = tmp;
			}
		}
	}
}

int main()
{
	student stuAry[5] = {
							{ "Joe", 171.5, 66.1, 'M', 95},
							{ "Dolly", 160.3, 55.3, 'F', 83},
							{ "Wallison", 175.5, 70.6, 'M', 92},
							{ "Andy", 168.5, 80.6, 'M', 88},
							{ "Helen", 155.5, 45.2, 'F', 77},
						};
	
	sortstudentAry(stuAry , 5);

	for(int i = 0 ; i < 5 ; i ++)
	{
		showstudent(stuAry[i]);
	}

	return 0;
}

