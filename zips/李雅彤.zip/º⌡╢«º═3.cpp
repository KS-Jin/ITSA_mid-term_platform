#include <iostream>
#include <string.h>
using namespace std;
char a ;
struct Student {
	char name [10];
	double tall;
	double heavy;
	char sad;
	double score;	
};

void showStudent(Student stuAry[],int L)
{ for (int k=0;k<L;k++)
	{cout<<stuAry[k].name<<","<<stuAry[k].tall<<","<<stuAry[k].heavy<<","<<stuAry[k].sad<<","<<stuAry[k].score<<endl;
    }
}
void sortStudent (Student stuAry[],int L)
{ 
  for (int c=0;c<L-1;c++)
  {
  	for (int i=0;i<L-1-c;i++)
  	{
  		if(a='B')
		{
		  if (stuAry[i].score < stuAry[i+1].score)
  		{
		Student tem = stuAry[i];
  		stuAry [i] = stuAry [i+1];
		stuAry [i+1] = tem;
	    }
	    }
	    else if (a='S')
	    {
	    if (stuAry[i].score > stuAry[i+1].score)
  		{
		Student tem = stuAry[i];
  		stuAry [i] = stuAry [i+1];
		stuAry [i+1] = tem;
	    }	
		}
	}
  }
}
int main()
{
	Student stuAry[5] = {
	                        {"Joe",171.5,66.1,'M',95},
						    {"Dolly",160.3,55.3,'F',83},
						    {"Wallison",175.5,70.6,'M',92},
						    {"Andy",168.5,80.6,'M',88},
						    {"Helen",155.5,45.2,'F',77},
						};
	cin>> a;
	
					
   	sortStudent (stuAry,5);		    
	showStudent (stuAry,5) ;					    
   return 0; 						
}

