#include <iostream>
#include <string.h>
using namespace std 

void 
{
	char name[10];
	double weight;
	char gender;
	double grade;
}Student;
	int main
	{
		Student studentAry[5]={
	                         {"joe",171.5,66.1,'M',95},
	                         {"Wallison",175.5,70.6,'M',92},
	                         {"Andy",168.5,80.6,'M',88},
							 {"Dolly",160.3,55.3,'F',83},
							 {"Helen",155.5,45.2,'F',77},
                          };
	}
	
	return 0;
};
