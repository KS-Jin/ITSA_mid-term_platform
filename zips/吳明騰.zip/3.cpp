#include <iostream>
#include <string.h>

using namespace std;
typedef struct
{
	char name[10];
	double high;
	double weight;
	char sex[3];
	double score;	
}Student;

bool BtoS(int a , int b)
{
	return a < b;
}

bool StoB(int a , int b)
{
	return a > b;
}

void sortStudentScore(Student* stuAry , int len ,bool(*ptr)(int,int))
{
//	int len = 5;
Student temp;
	for(int a = 0 ; a < len ; a++){
		for(int b = a + 1 ; b < len ; b++){
			if( ptr(stuAry[a].score , stuAry[b].score) ){
				temp = stuAry[a];
				stuAry[a] = stuAry[b];
				stuAry[b] = temp;
			}
		}
	}
}


void show(Student stu)
{
	cout<<stu.name<<","
		<<stu.high<<","
		<<stu.weight<<" ,"
		<<stu.sex<<","
		<<stu.score<<endl;
}
int main()
{
	Student studentAry[5]={
		
							{"Jon" ,171.5 ,66.1 , "M" ,95},
							{"Dolly" ,160.3 ,55.3 , "F" ,83},
							{"Wallison" ,175.5 ,70.6 , "M" ,92},
							{"Andy" ,168.5 ,80.6 , "M" ,88},
							{"Helen" ,155.5 ,42.5 , "F" ,77}
							
							};
							
	
	cout<<"�аݧA�n�p��Ƨ�?(�p�G�n�q�p�ƨ�j�п�JS�A�Y�n�Ѥj�ƨ�p�п�JB)"<<endl; 
	string check;
	cin>>check;
	if(check == "B")
	{
		sortStudentScore(studentAry , 5 ,BtoS);
		for(int a = 0 ; a < 5 ; a++){
		show( studentAry[a] );
	}
	}
	
	else if(check == "S") 
	{
		sortStudentScore(studentAry , 5 ,StoB);
		for(int a = 0 ; a < 5 ; a++){
		show( studentAry[a] );
	}
	}
	else{
		cout<<"error"<<endl;
	}
	
							
	return 0;
}
