#include<iostream>
#include<string.h>
using namespace std;

typedef struct
  { char name[10];
    double heigh;
    double weight;
    char sex;
    double grade;
  
  }Student;

bool btos(int a,int b)
{
  return a<b;
}
bool stob(int a,int b)
{
	return a>b;
}
  	


int main()
{ 
  
  Student studentAry[5]={
  	                      {"Joe",171.5,66.1,'M',95},
  	                      {"Dolly",160.36,55.3,'F',83},
  	                      {"Wallison",175.5,70.6,'M',92},
						  {"Andy",168.5,80.6,'M',88},
						  {"Helen",155.5,45.2,'F',77},
						};

  Student stuA;
   char z;
   cin>>z;
	for(int c=0;c<4;c++)
       { for(int i=0;i<4-c;i++)
         {   if(z=='B'||z=='b')
             {if(studentAry[i].grade<studentAry[i+1].grade)
             { 
			   stuA=studentAry[i];
               studentAry[i]=studentAry[i+1];
               studentAry[i+1]=stuA;
			 }
			 }
			else if(z=='S'||z=='s')
			{if(studentAry[i].grade>studentAry[i+1].grade)
             { 
			   stuA=studentAry[i];
               studentAry[i]=studentAry[i+1];
               studentAry[i+1]=stuA;
			 }
			 }
         	
		 }
       }
       
    for(int b=0;b<5;b++)
  {
	cout<<studentAry[b].name<<" "<<studentAry[b].heigh<<" "<<studentAry[b].weight 
	    <<" "<<studentAry[b].sex<<" "<<studentAry[b].grade<<endl;
  }
  
	
	return 0;
}
