#include <iostream>
using namespace std;
struct student
{
	char name;
	float high;
	float weigh;
	char sex;
	float grade;
	
};

int main()
{
	int i,k,j;
	student studentAry[5]=
	{
		
		{"Joe",171.5,66.1,'M',95},
		{"Dolly",160.3,55.3,'F',83},
		{"Wallison",175.5,70.6,'M',88},
		{"Andy",168.5,80.6,'M',88},
		{"Helen",155.5,45.2,'F',77}
	};
	student alter;
	for(j=0;j<5;j++)
	{
		
		
		for(i=0;i<5;i++)
		{
			if(sizeof(studentAry[i].grade)<sizeof(studentAry[i+1].grade))
			{
				alter=studentAry[i];
				studentAry[i]=studentAry[i+1];
				studentAry[i+1]=alter;
				
			}
		}
	}
	for( k=0;k<5;k++)
		cout<<studentAry[k];
	return 0;
	
}
