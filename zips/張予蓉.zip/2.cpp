#include <iostream>
using namespace std;

int Student;
	struct:
	{
	int name = 0;
	double tall = 0;
	double weight = 0;
	char sex = 0;
	int score = 0;
	};

main()
{
	
	Student studentAry[5]={
	{"Joe",171.5,66.1,'M',95},
	{"Dolly",160.3,55.3,'F',83},
	{"Willison",175.5,70.6,'M',92},
	{"Andy",168.5,80.6,'M',88},
	{"Helen",155.5,45.2,'F',77},
	};
	
	
	
	cout<<Student studentAry;
	
	
	
	
	
	
	return 0;
}
