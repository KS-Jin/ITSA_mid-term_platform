#include iostream
using namespace std
main()
find the answer on the following website~
https://goo.gl/99nLio


