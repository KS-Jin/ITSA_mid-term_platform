#include <iostream>
using namespace std;
main()
Student studentAry[5]=
{
	{"Joe",171.5,66.1,'M',95},
	{"Dolly",160.3,55.3,'F',83},
	{"Wallison",175.5,70.6,'M',88}
	{"Andy",168.5,80.6,'M',88}
	{"Helen",155.5,45.2,'F',77}
};

1st:Joe
2ed:Andy
3rd:Dolly
4th:Helen
5th:Wallison
