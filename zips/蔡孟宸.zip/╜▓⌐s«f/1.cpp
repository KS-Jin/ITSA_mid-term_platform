#include <iostream>
using namespace std;
main()
Ary[name]={Joe,Andy,Dolly,Helen,Wallison}

Ary[hight]={Helen,Dolly,Andy,Joe,Wallison}

Ary[weight]={Helen,Dolly,Joe,Wallison,Andy}

Ary[sexual]={}

Ary[score]={Helen,Dolly,Andy,Wallison,Joe}





Student studentAry[5]=
{
	{"Joe",171.5,66.1,'M',95},
	{"Dolly",160.3,55.3,'F',83},
	{"Wallison",175.5,70.6,'M',88}
	{"Andy",168.5,80.6,'M',88}
	{"Helen",155.5,45.2,'F',77}
};


