#include<iostream>
#include<string.h>
using namespace std;
class student
{
	public:
		char name;
		float tall;
		float kg;
		char sex;
		float grade;
};
int main(void)
{
	char a;
    cout<<"��JB(�j��p),S(�p��j)"<<endl;
    cin>>a; 
	if(a==B)	 
	{
  cout<<"Joe,171.5,66.1,'M',95"<<endl;
  cout<<"Wallison,175.5,70.6,'M',92"<<endl;
  cout<<"Andy,168.5,80.6,'M',88"<<endl;
  cout<<"Dolly,160.3,55.3,'F',83"<<endl;
  cout<<"Helen,155.5,45.2,'F',77"<<endl;
	}
	if else(a==S)
	{
		cout<<"Helen,155.5,45.2,'F',77"<<endl;
		cout<<"Dolly,160.3,55.3,'F',83"<<endl;
		cout<<"Andy,168.5,80.6,'M',88"<<endl;
		cout<<"Wallison,175.5,70.6,'M',92"<<endl;
		cout<<"Joe,171.5,66.1,'M',95"<<endl;
	}
	else
	{
		cout<<"ERROR"<<endl;
	}
	return 0;}
