#include<iostream>
using namespace std;

typedef struct{
	string name;
	float high;
	float weight;
	char sex;
	int grade;
}Student;

int main()
{
	Student studentAry[5] = {
		{"Joe", 171.5, 66.1, 'M', 95},
		{"Dolly", 160.3, 55.3, 'F', 83},
		{"Wallison", 175.5, 70.6, 'M', 92},
		{"Andy", 168.5, 80.6, 'M', 88},
		{"Helen", 155.5, 45.2, 'F', 77},
	};
	
	int l = 5;
	char cho;
	cout<<"�п�JB:�Ѥj��p��S:�Ѥp��j ";
	cin>>cho; 
	if(cho == 'B'){ 
	for(int c = 0; c < l-1; c++)
		{
			for(int i = 0; i < l - c -1; i++)	
			{
				if(studentAry[i].grade < studentAry[i+1].grade)
				{
					int tmp = studentAry[i].grade;
					string name = studentAry[i].name;
					float high = studentAry[i].high;
					float weight = studentAry[i].weight;
					char sex = studentAry[i].sex;
					studentAry[i].grade = studentAry[i+1].grade;
					studentAry[i+1].grade = tmp;
					studentAry[i].name = studentAry[i+1].name;
					studentAry[i+1].name = name;
					studentAry[i].high = studentAry[i+1].high;
					studentAry[i+1].high = high;
					studentAry[i].weight = studentAry[i+1].weight;
					studentAry[i+1].weight = weight;
					studentAry[i].sex = studentAry[i+1].sex;
					studentAry[i+1].sex = sex;
				}
			}
		}
		for(int i = 0; i < l; i++)
		{
			cout<<studentAry[i].name<<" ";
			cout<<studentAry[i].high<<" ";
			cout<<studentAry[i].weight<<" ";
			cout<<studentAry[i].sex<<" ";
			cout<<studentAry[i].grade<<" ";
			cout<<endl;
		}
	}else if(cho == 'S'){
		for(int c = 0; c < l-1; c++)
		{
			for(int i = 0; i < l - c -1; i++)	
			{
				if(studentAry[i].grade > studentAry[i+1].grade)
				{
					int tmp = studentAry[i].grade;
					string name = studentAry[i].name;
					float high = studentAry[i].high;
					float weight = studentAry[i].weight;
					char sex = studentAry[i].sex;
					studentAry[i].grade = studentAry[i+1].grade;
					studentAry[i+1].grade = tmp;
					studentAry[i].name = studentAry[i+1].name;
					studentAry[i+1].name = name;
					studentAry[i].high = studentAry[i+1].high;
					studentAry[i+1].high = high;
					studentAry[i].weight = studentAry[i+1].weight;
					studentAry[i+1].weight = weight;
					studentAry[i].sex = studentAry[i+1].sex;
					studentAry[i+1].sex = sex;
				}
			}
		}
		for(int i = 0; i < l; i++)
		{
			cout<<studentAry[i].name<<" ";
			cout<<studentAry[i].high<<" ";
			cout<<studentAry[i].weight<<" ";
			cout<<studentAry[i].sex<<" ";
			cout<<studentAry[i].grade<<" ";
			cout<<endl;
		}
	}else{
		cout<<"error"<<endl;
	}
	return 0;
}

