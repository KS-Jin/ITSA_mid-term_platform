#include <iostream>
using namespace std;

typedef struct
	{
		char* name;
		double tall;
		double weight;
		char* sex;
		double grade;
	}student;
	

int main ()
{
	student studentary[5]={
	   {"Joe",171.5,66.1,"M",95},
	   {"Dolly",160.3,55.3,"F",83},
	   {"Wallison",175.5,70.6,"M",92},
	   {"Andy",168.5,80.6,"M",88},
	   {"Helen",155.5,45.2,"F",77},
	};
 
    	cout<<studentary[0].name<<","<<studentary[0].tall<<","<<studentary[0].weight<<","<<studentary[0].sex<<","<<studentary[0].grade<<endl;
	    cout<<studentary[2].name<<","<<studentary[2].tall<<","<<studentary[2].weight<<","<<studentary[2].sex<<","<<studentary[2].grade<<endl;
	    cout<<studentary[3].name<<","<<studentary[3].tall<<","<<studentary[3].weight<<","<<studentary[3].sex<<","<<studentary[3].grade<<endl;
	    cout<<studentary[1].name<<","<<studentary[1].tall<<","<<studentary[1].weight<<","<<studentary[1].sex<<","<<studentary[1].grade<<endl;
	    cout<<studentary[4].name<<","<<studentary[4].tall<<","<<studentary[4].weight<<","<<studentary[4].sex<<","<<studentary[4].grade<<endl;

system("pause");
return 0;
}
