#include <iostream>
#include <string.h>
using namespace std;

class Student {
public:	
	char name[10];
	double high;
	double weight;
	char sex[10];
	double point;
};

void showStudent(Student& stu)
{
	cout<<stu.name<<","<<stu.high <<","<<stu.weight<<","
		<<stu.sex<<","<<stu.point <<endl;
}

int main()
{
	Student stuA = {"Joe",171.5,66.1,"M",95};
	Student stuB = {"Dolly",160.3,55.3,"F",83};
	Student stuC = {"Wallison",175.5,70.6,"M",92};
	Student stuD = {"Andy",168.5,80.6,"M",88};
	Student stuE = {"Helen",155.5,45.2,"F",77};

	showStudent(stuA);
	showStudent(stuC);
	showStudent(stuD);
	showStudent(stuB);
	showStudent(stuE);
	
	return 0;
}


