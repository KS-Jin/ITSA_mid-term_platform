#include <iostream>
#include <cstring>
using namespace std;

studentAry[5] = {string, float, float, char, float}

int main()
{
struct Student studentAry[5]={
						{"Joe", 171.5, 66.1, 'M', 95},
						{"Dolly", 160.3, 55.3,'F', 83},
						{"Wallison", 175.5, 70.6, 'M', 92},
						{"Andy", 168.5, 80.6, 'M', 88},
						{"Helen", 155.5, 45.2, 'F', 77},
					};
cout<<"Is it too late now to say sorry"<<endl;

char key;
cin>>key;
if(key='B')
cout<<"�ƧǥѤj��p";
else if(key='S')
cout<<"�ƧǤp��j";
else
cout<<"�藍�_ �ڤW�Ҹӻ{�uť�� <:3";
}
