#include <iostream>
using namespace std;


int main(){


cout<<"Joe , 175.5 , 66.1 , 'M' , 95\n";
cout<<"Andy , 168.5 , 80.6 , 'M' ,88\n";
cout<<"Dolly , 160.3 , 55.3 , 'F' , 83\n";
cout<<"Helen , 155.5 , 45.2 , 'F' , 77\n";
cout<<"Wallison , 175.5 , 70.6 , 'M' , 92\n";

	
	
}
