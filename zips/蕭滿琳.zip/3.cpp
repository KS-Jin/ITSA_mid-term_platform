#include <iostream>
using namespace std;
int main(){
	cout<<"��հ�\n";
	cout<<"I didn't study \n";
	
	return 0;
}
