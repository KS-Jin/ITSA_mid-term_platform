#include <iostream>
#include <string.h>
using namespace std;

typedef struct {
	char name[10];
	double cm;
	double kg;
	char gander;
	double grade;
}Student;

void show(const Student& stu)
{
	cout<<stu.name<<","<<stu.cm<<","<<stu.kg<<","<<stu.gander<<stu.grade<<endl;
}

bool StoB(int a , int b)
{
	return a > b;
}
double compare(const Student& stu)
{
	return stu.grade;
}

void sortStudentAry(Student* stuentAry , int L , bool (*ptrWay)(int , int) , double (*ptrScore)(const Student&))
{
	for(int a=0; a<L-1 ; a++)
	{
		for(int i=0 ; i<L-1-a ; i++)
		{
			if(ptrWay( ptrScore(stuentAry[i]) , ptrScore(stuentAry[i + 1]) ))
			{
				Student tmp = stuentAry[i];
				stuentAry[i] = stuentAry[i+1];
				stuentAry[i+1] = tmp;
			}
		}
	}
}

int main()
{
	Student stuentAry[5]={
						{"Joe",171.5,66.1,'M',95},
						{"Dolly",160.3,55.3,'F',83},
						{"Wallison",175.5,70.6,'M',92},
						{"Andy",165.5,80.6,'M',88},
						{"Helen",155.5,45.2,'F',77},	
					   };

	sortStudentAry(stuentAry , 5 , StoB , compare);
	
	for(int i = 0 ; i < 5 ; i ++)
	{
		show(stuentAry[i]);
	}

	return 0;
}
