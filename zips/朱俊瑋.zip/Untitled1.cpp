#include<iostream>
#include<string.h>
using namespace std;

typedef struct{
	string name;
	double h;
	double w;
	char sex;
	double s;
}student;

int main()
{
	int i,j;
	student temp;
	student studentAry[5]={
		{"Joe",171.5,66.1,'M',95},
		{"Dolly",160.3,55.3,'F',83},
		{"Wallison",175.5,70.6,'M',92},
		{"Andy",168.5,80.6,'M',88},
		{"Helen",155.5,45.2,'F',77},
		};
	for(i=0;i<5;i++){
		for(j=0;j<4-i;j++){
			if(studentAry[j].s<studentAry[j+1].s){
				temp=studentAry[j];
				studentAry[j]=studentAry[j+1];
				studentAry[j+1]=temp;
			}
		}
	}
	for(i=0;i<5;i++){
		cout<<studentAry[i].name<<","<<studentAry[i].h<<","<<studentAry[i].w<<","<<studentAry[i].sex<<","<<studentAry[i].s<<endl;
	}
}
