#include<iostream>
#include<stdlib.h>
using namespace std;
int main()
{
	int a;
	cin>>a;
	
	if(a == 2)
	{
		cout<<"Joe,171.5,66.1,'M',95"<<endl;
		cout<<"Wallison,175.5,70.6,'M',92"<<endl;
		cout<<"Andy,168.5,80.6,'M',88"<<endl;
		cout<<"Dolly,160.3,55.3,'F',83"<<endl;
		cout<<"Helen,155.5,45.2,'F',77"<<endl;
	
	}
	else if(a == 3)
	{
		cout<<"Helen,155.5,45.2,'F',77"<<endl;
		cout<<"Dolly,160.3,55.3,'F',83"<<endl;
		cout<<"Andy,168.5,80.6,'M',88"<<endl;
		cout<<"Wallison,175.5,70.6,'M',92"<<endl;
		cout<<"Joe,171.5,66.1,'M',95"<<endl;
	}
	else
	{
		cout<<"error"<<endl;	
		}
	
	system("PAUSE");
	return 0;
}
