#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<string>
using namespace std;
struct student
{
	string name;
	float len;
	float hei;
	char m;
	float grade;
};
void show(struct student stu)
{
		cout << stu.name << "," << stu.len << "," << stu.hei << "," << stu.m << "," << stu.grade;
}
int main()
{
	struct student studentAry[5] = {
								{"Joe",171.5,66.1,'M',95},
								{"Dolly",160.3,55.3,'F',83},
								{"Wallison",175.5,70.6,'M',92},								
								{"Andy",168.5,80.6,'M',88},
								{"Helen",155.5,45.2,'F',77}
							};
	for(int l=0;l<5;l++)
	{
		for(int a=0;a<4;a++)
		{
			if(studentAry[a].name.length()>studentAry[a+1].name.length())
			{
				struct student temp = studentAry[a];
				studentAry[a]=studentAry[a+1];
				studentAry[a+1]=temp;
			}
		}
	}
	for(int i=0;i<5;i++)
	{
		show(studentAry[i]);
		cout << endl;
	}
	system("pause");
	return 0;
}
