#include <iostream>
using namespace std;
int main()
{
	cout<<"QAQ";
	return 0;
}
