#include <iostream>
using namespace std;
typedef struct
{	char name[50];
	double height;
	double weight;
	char sex[10];
	double score;
} Student;
void sortStudentbyscore(Student* studentAry)
{
for(int i=0; i<5; i++)
{if(studentAry[i].score<studentAry[i+1].score)
{
Student* tmp=&studentAry[i];
studentAry[i]=studentAry[i+1];
studentAry[i+1]=*tmp;
}
else
{cout<<studentAry[i].name<<","<<studentAry[i].height<<","<<studentAry[i].weight<<","
<<studentAry[i].sex<<","<<studentAry[i].score<<endl;}
}}
int main()
{
    Student studentAry[5]={
	{"Joe",171.5,66.1,"'M'",95},
	
	{"Wallison",175.5,70.6,"'M'",92},
	{"Andy",168.5,80.6,"'M'",88},
    {"Dolly",160.3,55.3,"'F'",83},
 	{"Helen",155.5,45.2,"'F'",77}
	};
	sortStudentbyscore(studentAry);
	return 0;

}
	
