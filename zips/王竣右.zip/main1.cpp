#include <iostream>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
    int studentAry[5];
	 studentAry[5];
	 {
    	{"Joe",171.5,66.1,'M',95},
    	{"Wallison",175.5,70.6,'M',92},
		{"Andy",168.5,80.6,'M',88},
	    {"Dolly",160.3,55.3,'F',83},
		{"Helen",155.5,45.2,'F',77;},  	
	};
	cout<<Student studentAry[0]<<endl;
	cout<<Student studentAry[1]<<endl;
	cout<<Student studentAry[2]<<endl;
	cout<<Student studentAry[3]<<endl;
	cout<<Student studentAry[4]<<endl; 
	return 0;
}
