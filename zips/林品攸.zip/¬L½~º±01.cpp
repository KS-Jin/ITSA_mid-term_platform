#include <iostream>
#include <stdio.h>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//class Student
//{
	//public:
		string _n[5]={"Joe","Dolly","Wallison","Andy","Helen"};
		double t[5]={171.5,160.3,175.5,168.5,155.5};
		double w[5]={66.1,55.3,70.6,80.6,45.2};
		char   m[5]={'M','F','M','M','F'};
		double s[5]={95,83,92,88,77};
//}
int main(int argc, char** argv) 
{   cout<<"Student studentAry[5]={"<<endl;
    cout<<"{";
    cout<<_n[0]<<","<<t[0]<<","<<w[0]<<","<<m[0]<<","<<s[0];
    cout<<"},";
    cout<<endl;
    cout<<"{";
    cout<<_n[2]<<","<<t[2]<<","<<w[2]<<","<<m[2]<<","<<s[2];
    cout<<"},";
    cout<<endl;
    cout<<"{";
    cout<<_n[3]<<","<<t[3]<<","<<w[3]<<","<<m[3]<<","<<s[3];
    cout<<"},";
    cout<<endl;
    cout<<"{";
	cout<<_n[1]<<","<<t[1]<<","<<w[1]<<","<<m[1]<<","<<s[1];
	cout<<"},";
    cout<<endl;
    cout<<"{";
    cout<<_n[4]<<","<<t[4]<<","<<w[4]<<","<<m[4]<<","<<s[4];
    cout<<"},";
    cout<<endl;
    cout<<"};";
    return 0;
}
