#include <iostream>
#include <string.h>
using namespace std ;

typedef struct{
    char name[10];
    double high;
    double weight;
    char sex;
    double score;
}Student;

bool BtoS(double a , double b)
{
    return a < b ;
}

bool StoB(double a , double b)
{
    return a > b ;
}

void SortAry(Student *stu , bool(*kind)(double,double))
{
	for(int L = 0 ; L < 5 ; L ++)
	{
	    for(int i = 0 ; i < 4 ; i ++)
	    {
	        if( kind(stu[i].score,stu[i+1].score) )
	        {
		        Student tmp = stu[i] ;
		        stu[i] = stu[i+1] ;
		        stu[i+1] = tmp ;
	        }
        }
    }
}

void ShowAry(Student *stu)
{
	for(int i = 0 ; i < 5 ; i ++)
	{
    cout<<stu[i].name<<","<<stu[i].high<<","<<stu[i].weight
	<<","<<stu[i].sex<<","<<stu[i].score<<endl;
	}
}

int main()
{
	Student studentAry[5]={
	                       {"Joe",171.5,66.1,'M',95},
						   {"Dolly",160.3,55.3,'F',83},
						   {"Wallison",175.5,70.6,'M',92},
						   {"Andy",168.5,80.6,'M',88},
						   {"Helen",155.5,45.2,'F',77},
						  };
	char choose ;
	char s = 'S';
	char b = 'B';
	cout<<"��JB�i�o��̷Ӥ��ƱƧǥѤj��p,��JS�i�o��̷Ӥ��ƱƧǥѤp��j"<<endl; 
	cin>>choose;
	
	if(choose == b )
	{
        SortAry(&studentAry[0],BtoS);
	    ShowAry(&studentAry[0]);
    }
    else if(choose == s )
    {
        SortAry(&studentAry[0],StoB);
	    ShowAry(&studentAry[0]);
	}
	else
	{
		cout<<"��J���~!(�Ъ`�N�j�p�g)";
	}
	
	return 0 ;
}
