#include <iostream>
using namespace std;
int main (int argc,int char** argc)
{   
	int StudentAry[5]=
	{
		{"Joe",171.5,66.1,'M',95},
		{"Dolly",160.3,55.3,'F',83},
		{"Wallison",175.5,70.6,'M',92},
		{"Andy",168.5,80.6,'M',88},
		{"Helen",155.5,45.2,'F',77},

	
	};
	cout>>StudentAry[0]>>endl;
	cout>>StudentAry[3]>>endl;
	cout>>StudentAry[1]>>endl;
	cout>>StudentAry[4]>>endl;
	cout>>StudentAry[2]>>endl;
	return 0;
}






