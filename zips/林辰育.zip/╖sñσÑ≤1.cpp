#include<iostream>
#include<string.h>
using namespace std;



class student{
private:
	int English;
public:
	char name[10];
	int chinese;
	double math;
int getEnglish()
{
	return English;
}
void setEnglish(int value)
{
	 if(value<=100 && value>=0)
	 {
	 	English=value;
	 }
	 else
	 {
	 	cout<<"error";
	 }
}

void show()
{
	cout<<this->name<<"."<<this->chinese<<"."<<this->English<<"."<<this->math<<endl;
}
};

int main()
{
	student stuA;
	stuA.show();
    return 0;
}

