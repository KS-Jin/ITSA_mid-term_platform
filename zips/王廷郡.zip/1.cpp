#include<iostream>
#include<string>
#include<iomanip>

using namespace std;

struct Student
{
	string name;
	double lengh;
	double weigh;
	char sex;
	double score;
};

int main(){
	Student studentAry[5]=
	{
		{"Joe",171.5,66.1,'M',95},
		{"Dolly",160.3,55.3,'F',83},
		{"Willison",175.5,70.6,'M',92},
		{"Andy",168.5,80.6,'M',88},
		{"Helen",155.5,45.2,'F',77},
	};
	
	for(int i=0;i<5;i++){
		for(int j=i+1;j<5;j++){
			if(studentAry[j].score>studentAry[i].score){
				Student temp=studentAry[i];
				studentAry[i]=studentAry[j];
				studentAry[j]=temp;
			}
		}
	}
	
	for(int i=0;i<5;i++){
		cout<<setw(10)<<studentAry[i].name;
		cout<<setw(10)<<studentAry[i].lengh;
		cout<<setw(10)<<studentAry[i].weigh;
		cout<<setw(10)<<studentAry[i].sex;
		cout<<setw(10)<<studentAry[i].score;
		cout<<endl;
	}
} 
